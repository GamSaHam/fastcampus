package com.example.demo2;

import com.example.demo2.dto.MateApiCallQueueDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.RedisTemplate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Random;

@SpringBootTest
class Demo2ApplicationTests {

    private final String QUEUE_NAME = "mate.apicall";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    RedisTemplate redisTemplate;
    @Test
    void contextLoads() throws JsonProcessingException, InterruptedException {


        for (int i = 1; i <= 1000; i++) {
            MateApiCallQueueDTO mateApiCallQueueDTO = new MateApiCallQueueDTO();
            mateApiCallQueueDTO.setUserIdx(String.valueOf(new Random().nextInt(1, 10)));
            mateApiCallQueueDTO.setStartUserIdx("102");
            mateApiCallQueueDTO.setServiceStatus("started");
            mateApiCallQueueDTO.setIndex(String.valueOf(i));

            redisTemplate.opsForList().rightPush(QUEUE_NAME, objectMapper.writeValueAsString(mateApiCallQueueDTO));
        }

    }


    @Test
    public void validData() {

        ClassPathResource resource = new ClassPathResource("test.txt");

        HashMap<String, Integer> hashMap = new HashMap<>();


        try (BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()))) {
            String line;
            // 파일의 각 줄을 읽어 출력
            while ((line = br.readLine()) != null) {


                MateApiCallQueueDTO mateApiCallQueueDTO =  objectMapper.readValue(line, MateApiCallQueueDTO.class);


                if(hashMap.containsKey(mateApiCallQueueDTO.getUserIdx())) {
                    int currentIndex = hashMap.get(mateApiCallQueueDTO.getUserIdx());

                    if(currentIndex > Integer.parseInt(mateApiCallQueueDTO.getIndex())) {
                        System.out.println("###############error");
                        throw new RuntimeException("error");
                    }

                }
                hashMap.put(mateApiCallQueueDTO.getUserIdx(), Integer.parseInt(mateApiCallQueueDTO.getIndex()));


                System.out.println(mateApiCallQueueDTO.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }




}
