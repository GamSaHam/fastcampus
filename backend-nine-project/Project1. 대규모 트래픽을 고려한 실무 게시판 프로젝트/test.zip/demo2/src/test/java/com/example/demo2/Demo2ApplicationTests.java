package com.example.demo2;

import com.example.demo2.dto.MyMessageDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Random;

@SpringBootTest
class Demo2ApplicationTests {

    @Autowired
    RedisTemplate redisTemplate;
    @Test
    void contextLoads() throws JsonProcessingException, InterruptedException {

        String[] userIdx = {"test", "test2"};

        for (int j = 0; j < 5; j++) {

            for (int i = 0; i < 100; i++) {
                MyMessageDTO myMessageDTO = new MyMessageDTO();
                myMessageDTO.setUserIdx(userIdx[new Random().nextInt(0, 1)]);
                myMessageDTO.setMessage(String.valueOf(i));

                ObjectMapper objectMapper = new ObjectMapper();
                String jsonString = objectMapper.writeValueAsString(myMessageDTO);

                redisTemplate.opsForList().rightPush("my-queue", jsonString);
            }

            Thread.sleep(((new Random().nextInt(1,5))*1000));

        }


    }

}
