package com.example.demo2;

import com.example.demo2.dto.MyMessageDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Random;

@SpringBootTest
class Demo2ApplicationTests {

    private final String QUEUE_NAME = "mate.apicall";

    @Autowired
    RedisTemplate redisTemplate;
    @Test
    void contextLoads() throws JsonProcessingException, InterruptedException {

        String userIdx = "15786";
        String userIdx2 = "17856";

        // ####################################
        MyMessageDTO myMessageDTO = new MyMessageDTO();
        myMessageDTO.setUserIdx(userIdx);
        myMessageDTO.setMessage(String.format("userIdx:%s, start index:%d", userIdx, 1));
        myMessageDTO.setApiCallSuccess(false);

        ObjectMapper objectMapper = new ObjectMapper();


        redisTemplate.opsForList().rightPush(QUEUE_NAME, objectMapper.writeValueAsString(myMessageDTO));


        // ####################################
        myMessageDTO = new MyMessageDTO();
        myMessageDTO.setUserIdx(userIdx2);
        myMessageDTO.setMessage(String.format("userIdx:%s, start index:%d", userIdx2, 1));
        myMessageDTO.setApiCallSuccess(true);

        redisTemplate.opsForList().rightPush(QUEUE_NAME, objectMapper.writeValueAsString(myMessageDTO));



        // ####################################
        myMessageDTO = new MyMessageDTO();
        myMessageDTO.setUserIdx(userIdx);
        myMessageDTO.setMessage(String.format("userIdx:%s, start index:%d", userIdx, 2));
        myMessageDTO.setApiCallSuccess(true);

        redisTemplate.opsForList().rightPush(QUEUE_NAME, objectMapper.writeValueAsString(myMessageDTO));

    }

}
