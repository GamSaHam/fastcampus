package com.example.demo2.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MyMessageDTO {
    private String userIdx;
    private String message;
    private boolean isApiCallSuccess; // 임시 api 성공 여부를 지정한다.
}
