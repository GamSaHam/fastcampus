//package com.example.demo;
//
//import com.example.demo.dto.MyMessageDTO;
//import com.example.demo.service.MyService;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.data.redis.core.RedisTemplate;
//
//// 테스트 환경 추가 필요
//@SpringBootTest
//class DemoApplicationTests {
//    private final String QUEUE_NAME = "mate.apicall";
//
//    @Autowired
//    private MyService myService;
//
//    @Autowired
//    RedisTemplate redisTemplate;
//
//    @BeforeEach
//    void setup() throws JsonProcessingException {
//        // 각 테스트가 실행되기 전에 실행할 구문
//        System.out.println("테스트가 실행되기 전입니다.");
//        MyMessageDTO myMessageDTO = new MyMessageDTO();
//        String userIdx = "15786";
//
//        myMessageDTO.setUserIdx(userIdx);
//        myMessageDTO.setMessage(String.format("userIdx:%s, start index:%d", userIdx, 1));
//        myMessageDTO.setApiCallSuccess(false);
//
//        ObjectMapper objectMapper = new ObjectMapper();
//
//        redisTemplate.opsForList().rightPush(QUEUE_NAME, objectMapper.writeValueAsString(myMessageDTO));
//
//    }
//    @Test
//    void contextLoads() {
//        String message = (String) redisTemplate.opsForList().leftPop(QUEUE_NAME);
//
//        myService.doSomething(message);
//        myService.failedQueue();
//
//
//    }
//
//}
