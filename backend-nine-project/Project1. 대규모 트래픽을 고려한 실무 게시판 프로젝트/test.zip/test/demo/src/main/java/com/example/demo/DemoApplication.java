package com.example.demo;

import com.example.demo.service.MyService;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.Duration;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Slf4j
@SpringBootApplication
@EnableScheduling
@EnableAsync
@RequiredArgsConstructor
public class DemoApplication implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    private final RedisTemplate<String, Object> redisTemplate;
    private final String QUEUE_NAME = "mate.apicall";
    private final MyService myService;
    private static boolean isAWorking = true;  // 스레드 A가 실행 중인지 여부

    @Override
    public void run(String... args) {
        // A 스레드
        Thread A = new Thread(() -> {

            while (true) {
//                System.out.println("Thread A is working...");

                try {
                    isAWorking = false;  // A 스레드가 멈춘 상태로 전환
                    String message = (String) redisTemplate.opsForList().leftPop(QUEUE_NAME, Duration.ofSeconds(0));
                    isAWorking = true;  // 다시 작업 상태로 전환

                    myService.doSomething(message);

                    Thread.sleep(10);
                } catch (Exception ignored) {
                }
            }
        });

        // B 스레드: A가 대기 중일 때만 실행
        // Queue 항목이 없으면 동기적으로 실행한다.
        Thread B = new Thread(() -> {
            try {
                while (true) {
                    if (!isAWorking) {
//                        System.out.println("Thread B is working while A is paused...");
                        myService.failedQueue();
                        Thread.sleep(200);  // B 스레드의 작업 (예: 1초 동안 작업)
                    }
                    // A가 계속 작업 중일 때 B는 아무것도 하지 않음
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        A.start();
        B.start();


    }

}