package com.example.demo.service;

import com.example.demo.dto.MyMessageDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

@Slf4j
@Service
public class MyService {

    @Autowired
    @Qualifier("mateTaskExecutor")
    private Executor mateTaskExecutor;

    private Deque<String> failedListJob = new LinkedList<>();
    private ConcurrentHashMap<String, Deque<String>> userIdxHashMap = new ConcurrentHashMap<>();

    private final ObjectMapper objectMapper = new ObjectMapper();

    public void doSomething(String message) {

        Runnable runnable = () -> {

            MyMessageDTO myMessageDTO = null;
            try {
                myMessageDTO = objectMapper.readValue(message, MyMessageDTO.class);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }

            if (userIdxHashMap.containsKey(myMessageDTO.getUserIdx())) {
                Deque<String> jobList = userIdxHashMap.get(myMessageDTO.getUserIdx());
                jobList.add(message);
                userIdxHashMap.put(myMessageDTO.getUserIdx(), jobList);
                return;
            }

            setUserIdxHashMap(message, myMessageDTO);
            boolean isApiCallSuccess = false;
            try {
                isApiCallSuccess = callApi(myMessageDTO, message);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if (isApiCallSuccess) {
                log.info(String.format("Message: %s, Thread Name: %s", myMessageDTO.getMessage(), Thread.currentThread().getName()));
                Deque<String> deque = userIdxHashMap.get(myMessageDTO.getUserIdx());
                deque.removeFirst();
                if (deque.isEmpty()) {
                    userIdxHashMap.remove(myMessageDTO.getUserIdx());
                } else {
                    userIdxHashMap.put(myMessageDTO.getUserIdx(), deque);
                }

            } else {
                failedListJob.add(message);
            }


        };

        mateTaskExecutor.execute(runnable);
    }

    private void setUserIdxHashMap(String message, MyMessageDTO myMessageDTO) {
        Deque<String> userIdxListJob = userIdxHashMap.get(myMessageDTO.getUserIdx());

        if (userIdxListJob == null) {
            Deque<String> jobList = new LinkedList<>();
            jobList.add(message);

            userIdxListJob = jobList;
        } else {
            userIdxListJob.add(message);
        }

        userIdxHashMap.put(myMessageDTO.getUserIdx(), userIdxListJob);
    }

    private boolean callApi(MyMessageDTO myMessageDTO, String message) throws InterruptedException {
        Thread.sleep(200);

        return myMessageDTO.isApiCallSuccess();
    }

    public void failedQueue() {

        if (!failedListJob.isEmpty()) {

            String message = failedListJob.peek();

            MyMessageDTO myMessageDTO = null;
            try {
                myMessageDTO = objectMapper.readValue(message, MyMessageDTO.class);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }

            if (userIdxHashMap.containsKey(myMessageDTO.getUserIdx())) {
                Deque<String> jobList = userIdxHashMap.get(myMessageDTO.getUserIdx());
                jobList.add(message);
                userIdxHashMap.put(myMessageDTO.getUserIdx(), jobList);
                return;
            }

            setUserIdxHashMap(message, myMessageDTO);

            boolean isApiCallSuccess = false;
            try {
                isApiCallSuccess = callApi(myMessageDTO, message);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if (isApiCallSuccess) {
                log.info(String.format("Message: %s, Thread Name: %s", myMessageDTO.getMessage(), Thread.currentThread().getName()));
                Deque<String> deque = userIdxHashMap.get(myMessageDTO.getUserIdx());
                deque.removeFirst();
                if (deque.isEmpty()) {
                    userIdxHashMap.remove(myMessageDTO.getUserIdx());
                } else {
                    userIdxHashMap.put(myMessageDTO.getUserIdx(), deque);
                }
            }
        }
    }

}

