package com.example.demo.service;

import com.example.demo.dto.MyMessageDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.hash.ObjectHashMapper;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

@Slf4j
@Service
public class MyService {

    @Autowired
    private Executor taskExecutor;

    private List list = new ArrayList<>();

    private static Set<String> set = new HashSet<>();
    public void doSomething(String message) {

        Runnable runnable = () -> {
            try {
                log.info(String.format("Message: %s, Thread Name: %s, List size: %d", message, Thread.currentThread().getName(), list.size()));
                ObjectMapper objectMapper = new ObjectMapper();

                MyMessageDTO myMessageDTO = objectMapper.readValue(message, MyMessageDTO.class);



//                Thread.sleep(10);

//                if(new Random().nextInt(0, 1) == 0) {
//                    log.info("success:" + message);
//                }else {
//                    log.info("failed" + message);
//                    set.add(myMessageDTO.getUserIdx());
//                }




            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };

        taskExecutor.execute(runnable);


    }

}
