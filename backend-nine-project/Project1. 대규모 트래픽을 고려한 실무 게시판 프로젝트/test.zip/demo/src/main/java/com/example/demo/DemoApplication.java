package com.example.demo;

import com.example.demo.service.MyService;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@SpringBootApplication
@EnableScheduling
@EnableAsync
@RequiredArgsConstructor
public class DemoApplication implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    private final RedisTemplate<String, Object> redisTemplate;

    private final String QUEUE_NAME = "my-queue";

    private final MyService myService;

    private int cnt = 0;

    @Override
    public void run(String... args) throws Exception {

        while (true) {
            try {
                String message = (String) redisTemplate.opsForList().leftPop(QUEUE_NAME, Duration.ofSeconds(0));

                myService.doSomething(message);
            } catch (Exception e) {
            }

        }

    }


}
