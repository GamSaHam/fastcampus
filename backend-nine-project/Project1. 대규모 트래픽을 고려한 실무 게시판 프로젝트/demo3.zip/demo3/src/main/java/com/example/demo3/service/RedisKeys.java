package com.example.demo3.service;

public class RedisKeys {
    public static final String QUEUE_KEY_PREFIX = "mate.apicall.";
    public static final String QUEUE_KEY = "mate.apicall";

    public static String getQueueKeyPrefix(int queueIndex) {
        return String.format("mate.apicall.%d", queueIndex);
    }

}
