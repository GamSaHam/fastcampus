package com.example.demo3.service;

import com.example.demo3.dto.MateApiCallQueueDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.List;

@Slf4j
public class MainRunnable implements Runnable{
    private final RedisTemplate<String, Object> redisTemplate;

    private final String QUEUE_KEY = "mate.apicall";

    private ObjectMapper objectMapper = new ObjectMapper();


    private final int THREAD_SIZE;

    public MainRunnable(final int THREAD_SIZE, RedisTemplate<String, Object> redisTemplate) {
        this.THREAD_SIZE = THREAD_SIZE;
        this.redisTemplate = redisTemplate;
    }

    private final int MAX_CHUNK_SIZE = 100;
    @Override
    public void run() {

        while(true) {

            Long listSize = redisTemplate.opsForList().size(QUEUE_KEY);

            if(listSize != null && listSize > 0){
                long readCount = Math.min(listSize, MAX_CHUNK_SIZE - 1);

                List<Object> items = redisTemplate.opsForList().range(QUEUE_KEY, 0, readCount);
                redisTemplate.opsForList().trim(QUEUE_KEY, readCount, -1);

                for (Object item : items) {
                    String message = (String)item;

                    MateApiCallQueueDTO mateApiCallQueueDTO = null;
                    try {
                        mateApiCallQueueDTO = objectMapper.readValue(message, MateApiCallQueueDTO.class);
                    } catch (JsonProcessingException e) {
                        log.error("error", e);
                        continue;
                    }

                    int queueIndex = Integer.parseInt(mateApiCallQueueDTO.getUserIdx()) % THREAD_SIZE;

//                    log.info("message" + message);
                    redisTemplate.opsForList().rightPush(RedisKeys.getQueueKeyPrefix(queueIndex), message);
                }
            }
        }

    }
}
