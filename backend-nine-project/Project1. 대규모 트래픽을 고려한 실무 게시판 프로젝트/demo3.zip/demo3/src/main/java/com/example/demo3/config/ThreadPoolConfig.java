package com.example.demo3.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class ThreadPoolConfig {

    @Value("${mate.thread-pool.core-size}")
    private int CORE_POOL_SIZE;

    @Value("${mate.thread-pool.max-size}")
    private int MAX_POOL_SIZE;

    @Value("${mate.thread-pool.queue-capacity}")
    private int QUEUE_CAPACITY;

    @Value("${mate.thread-pool.keep-alive-seconds}")
    private int KEEP_ALIVE_SECONDS;

    @Value("${mate.thread-pool.thread-name-prefix}")
    private String THREAD_NAME_PREFIX;

    @Bean("mateTaskExecutor")
    public Executor mateTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(Math.min(CORE_POOL_SIZE, Runtime.getRuntime().availableProcessors()));
        taskExecutor.setMaxPoolSize(MAX_POOL_SIZE);
        taskExecutor.setQueueCapacity(QUEUE_CAPACITY);
        taskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        taskExecutor.setThreadNamePrefix(THREAD_NAME_PREFIX);
        taskExecutor.initialize();
        return taskExecutor;
    }

}

