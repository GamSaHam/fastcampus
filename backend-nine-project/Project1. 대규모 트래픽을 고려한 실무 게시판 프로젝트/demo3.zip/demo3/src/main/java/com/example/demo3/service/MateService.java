package com.example.demo3.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class MateService {
    private final int THREAD_SIZE;
    private Thread mainThread;
    private Thread[] queueThreads;

    private final RedisTemplate<String, Object> redisTemplate;

    public MateService( @Value("${mate.thread-size}") int threadSize, @Qualifier("redisTemplate") RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
        this.THREAD_SIZE = threadSize;
        this.queueThreads = new Thread[this.THREAD_SIZE];
    }

    public void executeThreads() {
        MainRunnable mainRunnable = new MainRunnable(THREAD_SIZE, redisTemplate);

        mainThread = new Thread(mainRunnable);
        mainThread.start();

        for (int i = 0; i < THREAD_SIZE; i++) {
            QueueRunnable queueRunnables = new QueueRunnable(i, redisTemplate);
            queueThreads[i] = new Thread(queueRunnables);
            queueThreads[i].start();
        }
    }
}
