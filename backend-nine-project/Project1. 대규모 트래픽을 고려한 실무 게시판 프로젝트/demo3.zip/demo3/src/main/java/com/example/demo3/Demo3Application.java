package com.example.demo3;

import com.example.demo3.dto.MateApiCallQueueDTO;
import com.example.demo3.service.AsyncService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;

@SpringBootApplication
@RequiredArgsConstructor
public class Demo3Application implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(Demo3Application.class, args);
    }

    private final RedisTemplate<String, Object> redisTemplate;
    private final String QUEUE_NAME = "mate.apicall";
    private ObjectMapper objectMapper = new ObjectMapper();

    private final AsyncService asyncService;

    @Value("${mate.thread-pool.core-size}")
    private int CORE_POOL_SIZE;


    @Override
    public void run(String... args) throws Exception {

        while (true) {

            try {
                String message = (String) redisTemplate.opsForList().leftPop(QUEUE_NAME, Duration.ofSeconds(0));

                MateApiCallQueueDTO mateApiCallQueueDTO = objectMapper.readValue(message, MateApiCallQueueDTO.class);

                int queueIndex = Integer.parseInt(mateApiCallQueueDTO.getUserIdx()) % CORE_POOL_SIZE;

                asyncService.addTaskToQueue(queueIndex, mateApiCallQueueDTO);

            } catch (Exception ignored) {
            }

        }


    }
}
