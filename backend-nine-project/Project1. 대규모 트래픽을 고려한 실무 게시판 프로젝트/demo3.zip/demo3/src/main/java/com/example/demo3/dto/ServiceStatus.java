package com.example.demo3.dto;

public enum ServiceStatus {

    STARTED("started"),
    RENEWED("renewed"),
    FINISHED("finished"),
    CANCELED("canceled");

    private final String code;

    ServiceStatus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    // code 값에 따른 ServiceStatus 반환
    public static ServiceStatus valueOfCode(String code) {
        for (ServiceStatus status : ServiceStatus.values()) {
            if (status.getCode().equalsIgnoreCase(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }



}
