package com.example.demo3.service;

import com.example.demo3.dto.MateApiCallQueueDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.List;

@Slf4j
public class QueueRunnable implements Runnable{
    private final int QUEUE_INDEX;
    private final RedisTemplate<String, Object> redisTemplate;


    public QueueRunnable(int queueIndex, RedisTemplate<String, Object> redisTemplate) {
        this.QUEUE_INDEX = queueIndex;
        this.redisTemplate = redisTemplate;
    }
    private final int MAX_CHUNK_SIZE = 100;

    private ObjectMapper objectMapper = new ObjectMapper();
    @Override
    public void run() {

        while (true) {

            Long listSize = redisTemplate.opsForList().size(RedisKeys.getQueueKeyPrefix(QUEUE_INDEX));

            if (listSize != null && listSize > 0) {

                long readCount = Math.min(listSize, MAX_CHUNK_SIZE - 1);

                List<Object> items = redisTemplate.opsForList().range(RedisKeys.getQueueKeyPrefix(QUEUE_INDEX), 0, readCount);
                redisTemplate.opsForList().trim(RedisKeys.getQueueKeyPrefix(QUEUE_INDEX), readCount, -1);

                for (Object item : items) {
                    String message = (String)item;

                    if (message != null && !"".equals(message)) {
                        MateApiCallQueueDTO mateApiCallQueueDTO;
                        try {
                            mateApiCallQueueDTO = objectMapper.readValue(message, MateApiCallQueueDTO.class);
                        } catch (JsonProcessingException e) {
                            log.error("error", e);
                            continue;
                        }


                        executeTask(mateApiCallQueueDTO);
                    }
                }

            }
        }
    }



    public void executeTask(MateApiCallQueueDTO mateApiCallQueueDTO) {

        try {
            System.out.println(objectMapper.writeValueAsString(mateApiCallQueueDTO));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }
}
