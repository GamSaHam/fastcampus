//package com.example.demo3.service;
//
//import com.example.demo3.dto.MateApiCallQueueDTO;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import java.util.LinkedList;
//import java.util.Queue;
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.concurrent.Executor;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;
//
//@Slf4j
//@Service
//public class AsyncService {
//
//    private final Queue<MateApiCallQueueDTO>[] queueArray;
//    private final Executor mateTaskExecutor;
//    private ObjectMapper objectMapper = new ObjectMapper();
//
//    public AsyncService(@Value("${mate.thread-pool.core-size}") int CORE_POOL_SIZE, @Qualifier("mateTaskExecutor") Executor mateTaskExecutor) {
//        this.queueArray = new LinkedList[CORE_POOL_SIZE];
//        for (int i = 0; i < this.queueArray.length; i++) {
//            queueArray[i] = new LinkedList<>();
//        }
//
//        this.mateTaskExecutor = mateTaskExecutor;
//    }
//
//    public void addTaskToQueue(int queueIndex, MateApiCallQueueDTO mateApiCallQueueDTO) {
//        if (queueIndex >= 0 && queueIndex < queueArray.length) {
//            queueArray[queueIndex].add(mateApiCallQueueDTO);
//            processQueue(queueIndex);  // 큐에 작업이 추가되면 처리 시작
//        }
//    }
//
//    private final ConcurrentHashMap<Integer, Object> locks = new ConcurrentHashMap<>();
//
//    private void processQueue(int queueIndex) {
//        mateTaskExecutor.execute(() -> {
//            locks.putIfAbsent(queueIndex, new ReentrantLock());
//            Lock lock = (Lock) locks.get(queueIndex);
//
//            lock.lock(); // 락을 획득
//
//            Queue<MateApiCallQueueDTO> queue = queueArray[queueIndex];
//            while(!queue.isEmpty()){
//                MateApiCallQueueDTO mateApiCallQueueDTO = queue.poll();
//
//                executeTask(mateApiCallQueueDTO, queueIndex);
//            }
//
//            lock.unlock();
//
//        });
//    }
//
//
//    private void executeTask(MateApiCallQueueDTO mateApiCallQueueDTO, int queueIndex) {
//
//        try {
//            System.out.println(objectMapper.writeValueAsString(mateApiCallQueueDTO));
//        } catch (JsonProcessingException e) {
//            throw new RuntimeException(e);
//        }
//
////        log.info(String.format("Processing Task: userIdx:%s, index: %s, queueIndex: %d, threadName: %s"
////                , mateApiCallQueueDTO.getUserIdx()
////                , mateApiCallQueueDTO.getIndex()
////                , queueIndex
////                , Thread.currentThread().getName()
////        ));
//
//        try {
//            Thread.sleep(200);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//    }
//
//
//}
